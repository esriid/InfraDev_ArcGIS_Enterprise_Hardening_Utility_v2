from urllib.parse import quote
from core.models import TargetContext, ConnectionState
from core.url_normalizer import normalize_server_url
from connections.http_client import ArcGISHttpClient
from connections.token_manager import TokenManager
from connections.admin_endpoint_resolver import resolve as resolve_admin_endpoint


class FederationDiscovery:
    def __init__(self, client: ArcGISHttpClient, tokens: TokenManager):
        self.client = client
        self.tokens = tokens

    @staticmethod
    def _roles(data: dict) -> list[str]:
        values = []
        for key in ("serverRole", "serverFunction", "role", "function"):
            value = data.get(key)
            if value and value not in values:
                if isinstance(value, list):
                    values.extend(str(item) for item in value if str(item) not in values)
                else:
                    values.append(str(value))
        return values or ["FEDERATED_SERVER"]

    def discover(self, portal: TargetContext, portal_token: str) -> list[TargetContext]:
        urls = portal.metadata["urls"]
        payload = self.client.request_json(
            "GET", f"{urls['portal_admin']}/federation/servers",
            params={"token": portal_token, "f": "json"},
        )
        records = payload.get("servers") or payload.get("items") or []
        if isinstance(records, dict):
            records = list(records.values())
        results = []
        for index, record in enumerate(records):
            record = record if isinstance(record, dict) else {"id": str(record)}
            server_id = str(record.get("id") or record.get("serverId") or f"server-{index+1}")
            detail = dict(record)
            try:
                detail_payload = self.client.request_json(
                    "GET", f"{urls['portal_admin']}/federation/servers/{quote(server_id, safe='')}",
                    params={"token": portal_token, "f": "json"},
                )
                detail.update(detail_payload)
            except Exception:
                pass
            public_url = detail.get("url") or detail.get("serverUrl") or detail.get("servicesUrl")
            admin_url = detail.get("adminUrl") or detail.get("adminURL")
            if not admin_url or not public_url:
                # create a minimal context to record the unreachable server
                context = TargetContext(
                    target_id=server_id,
                    target_name=str(detail.get("name") or detail.get("serverName") or f"Federated Server {index+1}"),
                    component_type="server", deployment_mode="enterprise",
                    service_url=str(public_url or "") or None,
                    registered_admin_url=str(admin_url or "") or None,
                    roles=self._roles(detail), federation_state="federated", metadata=detail,
                )
                context.connection_state = ConnectionState.UNREACHABLE
                context.error = "Federation record tidak menyediakan adminUrl atau services URL."
                results.append(context)
                continue
            try:
                normalized_admin = normalize_server_url(str(admin_url))
                normalized_public = normalize_server_url(str(public_url))
                service_base = normalized_public["base"]
                registered_admin = normalized_admin["admin"]

                context = TargetContext(
                    target_id=server_id,
                    target_name=str(detail.get("name") or detail.get("serverName") or f"Federated Server {index+1}"),
                    component_type="server", deployment_mode="enterprise",
                    service_url=service_base,
                    registered_admin_url=registered_admin,
                    roles=self._roles(detail), federation_state="federated", metadata=detail,
                )

                # exchange a server token using the service base URL
                server_token = self.tokens.exchange_server_token(
                    urls["sharing_rest"], portal_token, service_base
                )

                # probe to resolve the effective admin endpoint
                def _probe(url: str) -> bool:
                    try:
                        self.client.request_json("GET", url, params={"token": server_token.token, "f": "json"})
                        return True
                    except Exception:
                        return False

                resolved = resolve_admin_endpoint(service_base, registered_admin, _probe)
                context.effective_admin_url = resolved.effective_admin_url
                context.connection_route = resolved.route

                root = self.client.request_json(
                    "GET", context.effective_admin_url,
                    params={"token": server_token.token, "f": "json"},
                )
                context.version = str(root.get("currentVersion") or root.get("version") or "Unknown")
                context.connection_state = ConnectionState.CONNECTED
            except Exception as exc:
                context.connection_state = ConnectionState.UNREACHABLE
                context.error = str(exc)
            results.append(context)
        return results
